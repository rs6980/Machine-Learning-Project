# Machine-Learning-project
Machine learning course project for NYU Machine learning course
This project is an implementation of the Kaggle's Microsoft Malware prediction challenge.
More details can be found in the below poster link
https://github.com/madscientist123/Machine-Learning-project/blob/master/MalwarePredictionChallengeFinalpdf(2).pdf
